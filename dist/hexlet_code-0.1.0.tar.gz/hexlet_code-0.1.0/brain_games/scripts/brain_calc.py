#!/usr/bin/env python3
from brain_games.games import my_calc
from brain_games.my_function import my_games


def main():
    my_games(my_calc)


if __name__ == '__main__':
    main()
