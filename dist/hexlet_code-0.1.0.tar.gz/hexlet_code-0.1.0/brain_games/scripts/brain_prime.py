#!/usr/bin/env python3
from brain_games.games import my_prime
from brain_games.my_function import my_games


def py_prime():
    my_games(my_prime)


if __name__ == '__main__':
    py_prime()
