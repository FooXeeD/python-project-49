from brain_games.cli import welcome_user


def my_games():
    print("Welcome to the Brain Games!")
    welcome_user()


if __name__ == '__main__':
    my_games()
