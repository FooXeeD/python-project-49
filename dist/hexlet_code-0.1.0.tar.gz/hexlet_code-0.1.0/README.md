### Hexlet tests and linter status:
[![Actions Status](https://github.com/FooXeeD/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/FooXeeD/python-project-49/actions)
<a href="https://codeclimate.com/github/FooXeeD/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/674c62326758c6382524/maintainability" /></a>
https://asciinema.org/a/7OyANTZiMcVZ8ekZH2G0GGSAc
https://asciinema.org/a/AZIn1lJKrIvNGucJkTKcnHa7b
https://asciinema.org/a/w6ZpBDkTo2BKtxamQZiepBt7I
https://asciinema.org/a/6PcN5ctFp2W8kPfQrRuHgfMca
